# Linux_Commands

## The folder is for archieving Useful linux commands and shell scripts. 

- linux-cmd.md -----------------------basic linux cmds*
- shell-bash.md ----------------------- basic shell-bash cmds
- vim-guide.md -----------------------basics for using vim (vi)
- regular-exp.md ----------------------regular expression supports for linux shell
- shell-scripts ----------------------folder keeps shell scripts
- linux-admin.md ------------------------- linux administration
- schedule-work.md ------------------------- linux scheduled works
- process-admin.md ------------------------- linux process administration
- rpm-yum.md --------------------------- applications install/management